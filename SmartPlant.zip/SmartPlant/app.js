document.querySelector("#con").addEventListener("click", () => {
    window.open("data.html", "_blank");
});
document.getElementById("chatbot").addEventListener("click", ()=>{
    window.open("", "/blank");
})
