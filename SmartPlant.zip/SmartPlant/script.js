// Import the Firebase functions you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.3.0/firebase-app.js";
import { getDatabase, ref, onValue } from "https://www.gstatic.com/firebasejs/10.3.0/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCTG6zsr5jh7NNETtUEhl5Jf6AYVWNmwXw",
  authDomain: "plantirrigation-e3561.firebaseapp.com",
  databaseURL: "https://plantirrigation-e3561-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "plantirrigation-e3561",
  storageBucket: "plantirrigation-e3561.appspot.com",
  messagingSenderId: "663315896424",
  appId: "1:663315896424:web:18b3e209b182127a4f83dd",
  measurementId: "G-EP39ZQTQMY"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Realtime Database
const database = getDatabase(app);

// Reference the Eco-Grow data
const humidityRef = ref(database, 'eco-grow/Humidity');
const soilMoistureRef = ref(database, 'eco-grow/Soil_moisture');
const temperatureRef = ref(database, 'eco-grow/Temperature');

// Listen for changes in the database and update the webpage
onValue(humidityRef, (snapshot) => {
  const humidity = snapshot.val();
  document.getElementById('humidity').innerText = `Humidity: ${humidity}%`;
});

onValue(soilMoistureRef, (snapshot) => {
  const soilMoisture = snapshot.val();
  document.getElementById('soilMoisture').innerText = `Soil Moisture: ${soilMoisture}%`;
});

onValue(temperatureRef, (snapshot) => {
  const temperature = snapshot.val();
  document.getElementById('temperature').innerText = `Temperature: ${temperature}°C`;
});